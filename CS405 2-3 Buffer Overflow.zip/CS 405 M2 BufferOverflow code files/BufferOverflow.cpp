// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <conio.h>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  std::string user_input = ""; // cast user_input as std::string instead of char[] to allow concatenation and prevent memory leaks
  int max_input_length = 20;

  std::cout << "Enter a value: ";
  
  // request user input until ENTER pressed or until input exceeds size allowed (twenty characters, in this case)
  char c = NULL;
  int i = 0;
  while (c != '\r') {
    c = getch();
	std::cout << c;
	user_input = user_input + c;
	++i;

	// notify of buffer potential buffer overflow and break out of loop 
	if (i >= max_input_length) {
      std::cout << "\nAlert: Buffer overflow!";
	  break;
	}
  }

  std::cout << "\nYou entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;

  while (1) {
    continue;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
